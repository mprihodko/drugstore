<?php
    
    if(isset($_GET['logout'])){
        unset($_SESSION);
        session_unset();
    }

    $page = (isset($_GET['page']))? $_GET['page'] : null;
    $pos = strpos($page, "/");
    if($pos)
        $page = substr(str_replace("/", '', $page), 0, $pos);

    if(isset($_POST['action'])){
        if($_POST['action'] == 'user_login'){        
            $log = filter_var($_POST['log'], FILTER_VALIDATE_EMAIL);
            if(!$log){
                $log = filter_var($_POST['log'], FILTER_SANITIZE_STRING);
            }
            $pwd = filter_var($_POST['pwd'], FILTER_SANITIZE_STRING);
            $foreve = filter_var($_POST['rememberme'], FILTER_SANITIZE_STRING);
            login_user($log, $pwd, $foreve);
            return false;
        }
        if($_POST['action'] == 'user_registration'){
            $error = $user_id = register_user($_POST['username'], $_POST['email'], $_POST['password']);
            if(is_int($user_id))
                $message = 'Дякуємо за реєстрацію! Ласкаво просимо до нашого сайту!';
            else
                $message = 'Просимо вибачення при реєстрації виникли помилки спробуйте ще, або звернітся до нашої підтримки користувачів';
        }
        if($_POST['action'] == 'new_order'){
            if(isset($_POST['product']) && is_array($_POST['product'])){
                $error = $order_id = add_order($_POST);
                $_SESSION['cart']=null;
                $_SESSION['order_id']=$order_id;
                if(is_int($order_id)){
                    header('Location: '. get_home_url('thank_you/'));
                }
            }
        }
    }
    

    if($page == 'thank_you' && !isset($_SESSION['order_id']))
         header('Location: '. get_home_url());
    get_header();
    switch (stripslashes($page)) {
        case 'category':
                $id = $_GET['id'];
                $page = (isset($_GET['paged']))? (int)$_GET['paged']: 1;
                $id = str_replace("/", '', $id);
                $category = get_category($id);
                $offset = ($page-1)*6;
                $products = get_products_by_category($id, $offset, 6);
                include 'category.php';
            break;
        case 'registration':
                include 'registration.php';
            break;
        case 'product':
                $id = $_GET['id'];
                $id = str_replace("/", '', $id);
                $product = get_product($id);
                extract($product);
                if($node_type!='product')
                    header("Location: ".get_home_url());
                if(is_admin()){
                 
                }
                include 'single-product.php';
            break;
        case 'catalog':
            include 'catalog.php';
            break;
        case 'about':
            include 'about.php';
            break;
        case 'checkout':
            include 'checkout.php';
            break;
         case 'thank_you':
            include 'thank_you.php';
            unset($_SESSION['order_id']);
            break;
        default:
              include 'front-page.php';
            break;
    }
 
 
   get_footer();
?>