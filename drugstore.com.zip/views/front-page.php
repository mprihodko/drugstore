
<div class="banner diskont">
	<p class="main_diskont"><span>Лише тиждень - знижки на противірусні</span><span class="discount">15%</span></p>
</div>

<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container">
        <div class="row ">
            <div class="col-md-7 image-main" >
                <img  style="" src="<?php home_url('img/main.jpg'); ?>" width="100%">
            </div>
           	<div class="col-md-5">           		
                <h3 class="new_store" >Відділення №51 за адресою пр. Соборний 154</h3>

                <article class="article_1">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae voluptates ex voluptate exercitationem fuga velit maiores aspernatur. Odio deserunt suscipit sed aspernatur, a molestiae modi, ipsam ad necessitatibus neque alias. Animi ratione exercitationem earum debitis, mollitia, eos cumque ex at id, beatae fuga labore voluptatem corporis. Neque, reiciendis dolores adipisci. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo recusandae voluptatem aliquid incidunt at rem voluptatum, in, earum, saepe repellat blanditiis qui accusantium. Fugit molestiae, saepe corporis. Incidunt explicabo eligendi ad autem fugit ab excepturi voluptatum iste ipsam, tenetur quibusdam vero, accusantium eos provident sunt? Nostrum nulla, a deserunt harum.
                    </p>
                </article>                
           	</div>
        </div>      
    </div>
</div>
<div class="banner ads">
	<p class="main_adse"><span>Як вберегтися від застуди в холоди?</p>
</div>
<div class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container">
        <div class="row section_1">
        	<div class="col-md-12">
        		<h1 class="section_title">Поради наших фахівців</h1>
        		<div class="line"></div>
        		<div class="row section_1">
	        		<div class="col-md-6 doctor">
	        			<div class="doctor_face" style="background-image: url(<?php home_url('img/doctor1.jpg')?>)"></div>
	        		</div>
	        		<div class="col-md-6">
	        			<h3 class="new_store" >Анастасія</h3>
		                <article class="article_1">
		                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae voluptates ex voluptate exercitationem fuga velit maiores aspernatur. Odio deserunt suscipit sed aspernatur, a molestiae modi, ipsam ad necessitatibus neque alias. Animi ratione exercitationem earum debitis, mollitia, eos cumque ex at id, beatae fuga labore voluptatem corporis. Neque, reiciendis dolores adipisci. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo recusandae voluptatem aliquid incidunt at rem voluptatum, in, earum, saepe repellat blanditiis qui accusantium. Fugit molestiae, saepe corporis. Incidunt explicabo eligendi ad autem fugit ab excepturi voluptatum iste ipsam, tenetur quibusdam vero, accusantium eos provident sunt? Nostrum nulla, a deserunt harum.
		                    </p>
		                </article>
	        		</div>
	        		<div class="clearfix"></div>
	        	</div>
	        	<div class="row section_1">
	        		<div class="col-md-6">
	        			<h3 class="new_store" >Вікторія</h3>
		                <article class="article_1">
		                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae voluptates ex voluptate exercitationem fuga velit maiores aspernatur. Odio deserunt suscipit sed aspernatur, a molestiae modi, ipsam ad necessitatibus neque alias. Animi ratione exercitationem earum debitis, mollitia, eos cumque ex at id, beatae fuga labore voluptatem corporis. Neque, reiciendis dolores adipisci. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo recusandae voluptatem aliquid incidunt at rem voluptatum, in, earum, saepe repellat blanditiis qui accusantium. Fugit molestiae, saepe corporis. Incidunt explicabo eligendi ad autem fugit ab excepturi voluptatum iste ipsam, tenetur quibusdam vero, accusantium eos provident sunt? Nostrum nulla, a deserunt harum.
		                    </p>
		                  
		                </article>
	        		</div>
	        		<div class="col-md-6 doctor">
	        			<div class="doctor_face" style="background-image: url(<?php home_url('img/doctor2.jpg')?>)"></div>
	        		</div>
	        		<div class="clearfix"></div>
	        	</div>
	        	<div class="row ">
	        		<div class="col-md-6 doctor">
	        			<div class="doctor_face" style="background-image: url(<?php home_url('img/doctor3.jpg')?>)"></div>
	        		</div>
	        		<div class="col-md-6">
	        			<h3 class="new_store" >Олена</h3>
		                <article class="article_1">
		                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae voluptates ex voluptate exercitationem fuga velit maiores aspernatur. Odio deserunt suscipit sed aspernatur, a molestiae modi, ipsam ad necessitatibus neque alias. Animi ratione exercitationem earum debitis, mollitia, eos cumque ex at id, beatae fuga labore voluptatem corporis. Neque, reiciendis dolores adipisci. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo recusandae voluptatem aliquid incidunt at rem voluptatum, in, earum, saepe repellat blanditiis qui accusantium. Fugit molestiae, saepe corporis. Incidunt explicabo eligendi ad autem fugit ab excepturi voluptatum iste ipsam, tenetur quibusdam vero, accusantium eos provident sunt? Nostrum nulla, a deserunt harum.
		                    </p>
		                </article>
	        		</div>
	        		<div class="clearfix"></div>
	        	</div>
        	</div>
        </div>
    </div>
</div>
<div class="banner foot">
	<p class="main_diskont"><span>Бережіть Ваше здоров'я разом з нами!</p>
</div>
<div class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container">
        <div class="row section_1">
            <div class="col-md-12">
            	<h1 class="section_title">Популярні товари</h1>
            	<br>
            	<br>
                <?php $recent = recent_products();   ?>
                <div class="row main_hits">
                    <?php if($recent): ?>
                        <?php foreach ($recent as $product): $product = get_product($product['id']); ?>
                            <div class="main_hits_inform">                       
                                <div class="main_item_img">
                                    <img src="<?php echo $product['thumb']; ?>">
                                </div>
                                <div class="main_item-name"><?php echo $product['node_name']; ?>
                                </div>
                                <div class="btn-wrapper">
                                    <a href="<?php home_url('product/'.$product['id']);?>" class="btn btn-info btn-customize">Замовити Зараз!</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
