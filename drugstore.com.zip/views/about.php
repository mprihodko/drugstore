<div class="about about_top banner">
	<p class="main_diskont about_title">Завжди для Вас и Вашого здоров'я!</p>
</div>
<div class="container about_content">
	<div class="row">
		<div class="col-md-3 about_side">
			<h3><p>Корисна інформація</p></h3>
			<ul class="about_left">
				<li ><button type="button" class="about_left_item active" data-block="#portal"> Портал "Інфомед"</button></li>
				<li ><button type="button" class="about_left_item" data-block="#handbook"> Довідник</button></li>
				<li ><button type="button" class="about_left_item" data-block="#aboutus"> Про нас</a></button></li>
			</ul>	
		</div>
		<div class="col-md-9">
			<div id="portal" class="about_center active">
				<h3>Аптечный информационный портал "Инфомед"</h3>
				<p class="about_center_text">Аптечная информационная компания «Инфомед» - это комплекс сложного инженерно-технического оборудования и профессионального коллектива, позволяющий достойно выполнять поставленную перед предприятием задачу - бесперебойное обеспечение информацией населения.</p>
				<p class="about_center_text">Служба "0-67" ("15-67"), с мая 2016 года - "687", имеет огромный опыт работы на рынке информа- ционных услуг. Она была создана в 1986 году и являлась ПЕРВОЙ и, по сути, единственной на всей территории бывшего СССР, автоматизированной аптечной телефонной справочной службой. Создал и руководит этой службой по сей день с 1986 года Лапоногов Валерий Петрович. Провизор по образованию, выпускник Харьковского фармацевтического университета 1985 г. в.
				Предприятие развивается и уверенно двигается вперед: внедряются новые виды информационных каналов, развивается производственная, испытательная и исследовательская база, постоянно повышается качество предоставляемой информации, разрабатывается новое программное обеспечение. Служба вышла на принципиально новый по качеству, насыщенности и доступности уровень обслуживания. Расширились основные направления деятельности предприятия. На сегодняшний день это:</p>
				<ul>
					<li>информационно-справочное обслуживание аптек и медицинских учреждений,с целью увеличения притока покупателей и повышения товарооборота предприятия;</li>
					<li>информационно-справочное обслуживание населения по вопросам наличия медикаментов в аптечной сети города и их стоимости. Компьютерная база данных системы "Инфомед" обновляется ежедневно, и насчитывает свыше 14100 наименований лекарственных препаратов, лечебных косметологических средств, пищевых добавок и изделий медицинского назначения;</li>
					<li>оказание консультаций по различным вопросам лекарствоведения;</li>
					<li>информационно-справочное обслуживание населения о наличии препаратов в гомеопатических, диабетических, эндокринологических аптеках, о наличии товаров для ветеринарной медицины и животноводства в ветеринарных аптеках, о наличии инструментария, медтехники, ортопедических изделий, о работе слуховых Центров, диагностических кабинетов, лечебных учреждений;</li>
					<li>проведение маркетинговых и статистических исследований в области «спроса-предложения» фармацевтической продукции на основе деятельности справочных служб;</li>
					<li>реклама аптек и их деятельности в «Интернет». Создание личных WEB-страничек и размещение их на WEB-сайте www.apteki.kiev.ua с последующей программной поддержкой и необходимым дальнейшим обновлением; </li>
					<li>монтаж компьютерных систем для аптечных предприятий с учетом профессиональной специфики, финансовых возможностей и требований.</li>
				</ul>
			</div>
			<div id="handbook" class="about_center">
				<h3>Довідник</h3>
				<p class="about_center_text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam consequuntur commodi cumque nesciunt culpa, perferendis deserunt veniam ex officiis. Ratione in minima et recusandae earum eaque maiores commodi.
				</p>
			</div>	
			<div id="aboutus" class="about_center">
				<h3>Про нас</h3>
				<p class="about_center_text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi ducimus perferendis vel soluta tempora quos libero cumque ipsum iure fuga dolores neque veritatis quia, nostrum hic unde molestias, laborum, laudantium beatae quisquam itaque! Veniam officia, ratione pariatur! Expedita dolores, quisquam quia sit voluptates illum nemo ipsam voluptatum atque eaque, quae voluptatem distinctio, repudiandae fugit? Sed, laborum. Nihil labore, molestiae dignissimos.
				</p>
			</div>	
			 
		</div>
	</div>
</div>
<div class="about about_bottom banner">
	<p class="main_diskont about_title"><span>Ми працюємо цілодобово!</span></p>	
</div>