<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="<?php the_title(); ?>
	">
	<title><?php the_title(); ?></title>
	<link rel="shortcut icon" href="<?php home_url('img/favicon.png') ?>
	">
	<?php head(); ?>
	<script type="text/javascript">
		var ajaxUrl = "<?php admin_url('admin-ajax.php'); ?>";
	</script>
</head>
<body>
	<div class="cart-notice" id="added_notice">
		<span class="notice_message">Ліки внесені до кошику!</span>
	</div>
	</script>
	<header>
		<div class="header_top">
			<div class="container">
				<div class="social">
					<ul>
						<li>
							<a href="#"> <i class="facebook"></i>
							</a>
						</li>
						<li>
							<a href="#"> <i class="twiter"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="inst"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="goog"></i>
							</a>
						</li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="header-left">
					<div class="search-box">
						<div id="sb-search" class="sb-search">
							<form action="#" method="post">
								<input class="sb-search-input" placeholder="Введіть умови пошуку ..." type="search" id="search">
								<input class="sb-search-submit" type="submit" value="">
								<span class="sb-icon-search"></span>
							</form>
						</div>
					</div>
				</div>
				<script>
					jQuery(document).ready(function(){
						new UISearch( document.getElementById( 'sb-search' ) );
					});
				</script>
				 <script>
					jQuery(document).ready(function() {
				     	jQuery.scrollSpeed(100, 600);
				  	});
	     		 </script>

	     		<?php if(is_user_logged_in()): ?>

					<div class="ca-r">
						<div class="cart box_1">
							<a href="#" data-toggle="modal" data-target="#cart">
								<h3>
									<div class="total">
										<span class="simpleCart_total"><span class="totalPrice">0.00</span><span class="currency">грн</span></span>
									</div>
									<img src="<?php home_url('img/cart.png'); ?>" alt="Cart"></h3>
							</a>
							<p>
								<a href="#" class="simpleCart_empty">Очистити кошик</a>
							</p>
						</div>
					</div>

				<?php endif; ?>
				
			</div>
		</div>
		<div class="container">
			<div class="head-top clearfix">
				<div class="logo">
					<img src="<?php home_url('img/logo.png'); ?>" width="30%" alt="logo">
					<p class="logo_text">
						<span class="top_logo">
							<a href="<?php home_url(); ?>">Аптека «Барвинок»</a>
						</span>
						<span class="bot_logo">
							<i>Ліки за соціальними цінами</i>
						</span>
					</p>
				</div>
				<div class="main_menu_flex">
					<?php 

						$page = (isset($_GET['page']))? $_GET['page'] : null;
					    $pos = strpos($page, "/");
					    if($pos)
					        $page = substr(str_replace("/", '', $page), 0, $pos);
					?>
					<div class="main_menu_item <?php echo ($page == null)? 'current': '' ?>">
						<a href="<?php home_url('/')?>">Головна</a>
					</div>
					<div class="main_menu_item <?php echo ($page == 'about')? 'current': '' ?>">
						<a href="<?php home_url('about/')?>">Про аптеку</a>
					</div>
					<div class="main_menu_item <?php echo ($page == 'catalog' || $page == 'category' || $page == 'product')? 'current': '' ?>">
						<a href="<?php home_url('catalog/')?>">Каталог Ліків</a>
					</div>
					<?php if(is_user_logged_in()): ?>
					<div class="main_menu_item <?php echo ($page == 'registration')? 'current': '' ?>">
						<a href="<?php home_url('index.php?logout=true') ?>">Вийти</a>
					</div>
					<?php else: ?>
					<div class="main_menu_item <?php echo ($page == 'registration')? 'current': '' ?>">
						<a href="<?php home_url('registration/')?>">Реєстрація/Вхід</a>
					</div>
					<?php endif;?>
				</div>

			</div>
		</div>
	</header>
	<div id="main-container" class="main-content">
	   