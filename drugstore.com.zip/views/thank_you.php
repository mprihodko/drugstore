<div class="col-md-12">
	<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container category">

        <div class="breadCrumbs">
            <a href="<?php echo home_url(); ?>">Головна</a>
		</div>

		<div class="text-center col-lg-6 col-md-6 col-sm-6 col-xs-6">
			<img style="max-width:100%" src="http://drugstore.dev/img/logo.png" alt="logo">
			<h1 style="font-size: 70px;">Дякуємо за ваше замовлення!</h1>
			<h3 style="margin-top: 20px;">Замовлення №<?php echo $_SESSION['order_id'];?></h3>
		</div>
		<div class="text-center col-lg-6 col-md-6 col-sm-6 col-xs-6">
		
			<i class="fa fa-angellist fa-6 " style="opacity:0.5;font-size: 700px;" aria-hidden="true"></i>
		</div>
	</div>
</div>