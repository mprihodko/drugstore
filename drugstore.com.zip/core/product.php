<?php 

function get_products($offset=0, $limit=10){

	global $db; 
	$products = array();
	if($offset<0){
		$sql = "SELECT * FROM `nodes` WHERE `node_type`='product'";
	}else{
		$sql = "SELECT * FROM `nodes` WHERE `node_type`='product' LIMIT ".$offset.", ".$limit;
	}
	$request = mysqli_query($db, $sql);
	if($request){
		while ($row = mysqli_fetch_assoc($request)) {
			$products['products'][]=$row;
		}
	}
	$sql = "SELECT * FROM `nodes` WHERE `node_type`='product'";
	$request = mysqli_query($db, $sql);
	$products['num_rows']=ceil($request->num_rows/$limit);
	return (object)$products;

}

function get_product_attachment($id){

	if(!$id)
		return;
	$attachment_id = get_node_meta($id, 'product_thumb');
	$attachment = get_node($attachment_id);
	if(isset($attachment['node_name']))
		return $attachment['node_name'];
}

function get_product($id){

	if(!$id)
		return false;
	$product = get_node($id);
	if($product){
		$product['thumb']=get_product_attachment($product['id']);
		$product['price']=get_node_meta($product['id'], 'product_price');
		$product['categories'] = unserialize(get_node_meta($product['id'], 'category'));
		$product['offices'] = unserialize(get_node_meta($product['id'], 'office'));
		return $product;
	}else{
		return false;
	}
}

function recent_products(){

	global $db; 
	$products = array();

	$sql ="SELECT * FROM `nodes` WHERE `node_type` = 'product' ORDER BY id DESC LIMIT 4";
	$request = mysqli_query($db, $sql);
	if($request){
		while ($row = mysqli_fetch_assoc($request)) {
			$products[]=$row;
		}
	}
	return $products;

}