jQuery(document).ready(function($){

	var _Cart = {

		addToCartButton: $('.single_add_to_cart_button'),
		qtyInput: $("#qty"),
		cartTable: $("#cartTable tbody"),
		clearCart: $(".simpleCart_empty"),

		showNotice:function(){
			$("#added_notice").slideDown();
			setTimeout(function(){
				$("#added_notice").slideUp();
			}, 2500);
		},

		renderCart:function(){
			$.ajax({
					type:"POST",
					url: ajaxUrl,
					data:{					 
						action: 'render_cart'
					},
					success:function(json){
						response = $.parseJSON(json);
						_Cart.cartTable.html(response.html);
						$(".totalPrice").html(response.total)
						if(response.checkout){
							$("#checkoutButton").removeClass('disabled');
						}
					}
				});
		},

		removeFromCart:function(){

			$(document).on('click', ".delCartItem", function(e){
				e.preventDefault();
				var id = $(this).data('id');
				$.ajax({
					type:"POST",
					url: ajaxUrl,
					data:{	
						id: id,				 
						action: 'delete_from_cart'
					},
					success:function(response){
						$("#item-"+id).remove();
						$("#product-row-"+id).remove();
					}
				});
				

			});

		},

		addToCart: function(){
			_Cart.addToCartButton.on('click', function(e){
				e.preventDefault();
				var id = $(this).data('product');
				var qty = _Cart.qtyInput.val();

				$.ajax({
					type:"POST",
					url: ajaxUrl,
					data:{
						id: id,
						qty: qty,
						action: 'add_to_cart'
					},
					success:function(response){
						_Cart.renderCart();	
						_Cart.showNotice();					
					}
				});
			})


		},



		clearCartItems:function(){
			_Cart.clearCart.on('click', function(e){
				e.preventDefault();
				$.ajax({
					type:"POST",
					url: ajaxUrl,
					data:{						
						action: 'clear_cart'
					},
					success:function(response){
						_Cart.renderCart();
					}
				});
			})
		},

		init: function(){
			_Cart.renderCart();
			_Cart.addToCart();
			_Cart.removeFromCart();
			_Cart.clearCartItems();
		}


	}


	_Cart.init();

});
