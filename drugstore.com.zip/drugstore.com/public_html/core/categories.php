<?php 
	
function add_category($name, $description, $taxonomy){
	
	$error = array();
	if(!$name)
		$error['name'] = "Ім'я не може бути порожнім";
	if(count($error)>0)
		return $error;

	global $db;

	$sql = "SELECT * FROM `terms` WHERE `name`='".filter_var($name, FILTER_SANITIZE_STRING)."' AND `taxonomy`='".filter_var($taxonomy, FILTER_SANITIZE_STRING)."'";
	$request = mysqli_query($db, $sql);
	if($request){
		if(property_exists($request, 'num_rows')){
			if($request->num_rows>0)
				$error['name'] = "Таке ім'я вже існує";
		}
	}

	if(count($error)>0)
		return $error;

	$sql = "INSERT INTO `terms` (name, description, taxonomy) VALUES ('".filter_var($name, FILTER_SANITIZE_STRING)."', '".filter_var($description, FILTER_SANITIZE_STRING)."', '".filter_var($taxonomy, FILTER_SANITIZE_STRING)."')";
	$request = mysqli_query($db, $sql);
	if($request)
		return mysqli_insert_id($db);
	else
		return $error['undefined'] = "Сталася невідома помилка";
}

function get_categories($offset=0, $limit=10, $taxonomy){

	global $db; 
	$categories = array();
	if($offset<0){
		$sql = "SELECT * FROM `terms` WHERE `taxonomy`='".$taxonomy."'";
	}else{
		$sql = "SELECT * FROM `terms` WHERE `taxonomy`='".$taxonomy."' LIMIT ".$offset.", ".$limit;
	}
	$request = mysqli_query($db, $sql);
	if($request){
		while ($row = mysqli_fetch_assoc($request)) {
			$categories['categories'][]=$row;
		}
	}
	$sql = "SELECT * FROM `terms` WHERE `taxonomy`='".$taxonomy."'";
	$request = mysqli_query($db, $sql);
	$categories['num_rows']=ceil($request->num_rows/$limit);
	return (object)$categories;

}

function get_category($id=null){

	if(!$id)
		return;

	global $db;

	$sql = "SELECT * FROM `terms` WHERE `id` =".$id;
	$request = mysqli_query($db, $sql);
	if($request)
		return mysqli_fetch_assoc($request);
	else
		return false;
}

function edit_category($id, $name, $description){

	if(!$id)
		return;

	$error = array();
	if(!$name)
		$error['name'] = "Ім'я не може бути порожнім";
	if(count($error)>0)
		return $error;

	global $db;

	$sql = "SELECT `id` FROM `terms` WHERE `name`='".filter_var($name, FILTER_SANITIZE_STRING)."'";
	$request = mysqli_query($db, $sql);
	if($request){
		if(property_exists($request, 'num_rows')){
			if($request->num_rows>0){
				$category_id = mysqli_fetch_assoc($request)['id'];
				if($id != $category_id )
					$error['name'] = "Таке ім'я вже існує";
			}
		}
	}

	if(count($error)>0)
		return $error;

	$sql = "UPDATE `terms` SET `name`='".filter_var($name, FILTER_SANITIZE_STRING)."', `description` = '".filter_var($description, FILTER_SANITIZE_STRING)."' WHERE `id` = ".$id;
	$request = mysqli_query($db, $sql);
	if($request)
		return (int)$id;
	else
		return $error['undefined'] = "Сталася невідома помилка";
			
}

function delete_category($id){

	if(!$id)
		return;

	global $db;

	$sql ="DELETE FROM `terms` WHERE `id`=".$id;
	$request = mysqli_query($db, $sql);
	if($request)
		return true;
	else
		return false;

}

function get_products_by_category($id, $offset=0, $limit=9){

	if(!$id)
		return;

	global $db;

	$sql = 'SELECT `node_id` FROM `nodes_meta` WHERE `meta_key`="category" AND `meta_value` LIKE \'%"'.$id.'"%\' LIMIT '.$offset.', '.$limit;
	$request = mysqli_query($db, $sql);
	if(!$request)
		return false;
	while ($row = mysqli_fetch_assoc($request)) {
		$products['products'][]=$row;
	}
	$sql = 'SELECT `node_id` FROM `nodes_meta` WHERE `meta_key`="category" AND `meta_value` LIKE \'%"'.$id.'"%\'';
	$request = mysqli_query($db, $sql);
	$products['num_rows']=ceil($request->num_rows/$limit);
	return (object)$products;
}