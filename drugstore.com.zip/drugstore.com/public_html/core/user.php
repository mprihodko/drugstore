<?php 

/*Login Funtion*/

function login_user($log='', $pwd='', $foreve=''){
 
	if(is_user_logged_in())
		return false;
	if(!$log)
		return false;
	if(!$pwd)
		return false;

	global $db;

	$sql = "SELECT * FROM `user` WHERE `username` = '".$log."' OR `user_email` ='".$log."'";
	$response = mysqli_query($db, $sql);
	if($response)
		extract(mysqli_fetch_assoc($response));
	if($user_pass === md5($pwd)){		
		if($level === '10'){
			$_SESSION['admin'] = true;	
			$_SESSION['shop_manager'] = true;
			$_SESSION['user'] = true;
			$_SESSION['user_data']['id'] = $id;
			$_SESSION['user_data']['username'] = $username;
			$_SESSION['user_data']['user_email'] = $user_email;
			$_SESSION['user_data']['level'] = $level;
			if($foreve){
				setcookie('foreve', json_encode($_SESSION['user_data']),time()+3600*24*365, '/');
			}
			header('Location: '. get_home_url('admin'));
		}elseif($level === '5'){
			$_SESSION['admin'] = false;	
			$_SESSION['shop_manager'] = true;
			$_SESSION['user'] = true;	
			$_SESSION['user_data']['id'] = $id;
			$_SESSION['user_data']['username'] = $username;
			$_SESSION['user_data']['user_email'] = $user_email;
			$_SESSION['user_data']['level'] = $level;
			if($foreve){
				setcookie('foreve', json_encode($_SESSION['user_data']),time()+3600*24*365, '/');
			}
			header('Location: '. get_home_url('admin'));
		}else{
			$_SESSION['admin'] = false;	
			$_SESSION['shop_manager'] = false;
			$_SESSION['user'] = true;	
			$_SESSION['user_data']['id'] = $id;
			$_SESSION['user_data']['username'] = $username;
			$_SESSION['user_data']['user_email'] = $user_email;
			$_SESSION['user_data']['level'] = $level;
			if($foreve){
				setcookie('foreve', json_encode($_SESSION['user_data']),time()+3600*24*365, '/');
			}
			header('Location: '. get_home_url());
		}
	}else{
		header('Location: '. get_home_url('admin'));
	}
}

/*Get current user data*/

function get_user($id=''){

	if($id){
		global $db;
		$sql = "SELECT * FROM `user` WHERE `id` = ".$id;
		$response = mysqli_query($db, $sql);
		if($response)
			return mysqli_fetch_assoc($response);
	}else{
		return $GLOBALS['user'] = (object)$_SESSION['user_data'];
	}

}

/* get current user role*/

function curent_user_role(){

	global $user;

	if(!$user)
		$user = get_user();

	if($user->level === '5')
		$role = 'shop_manager';
	elseif($user->level === '10')
		$role = 'admin';
	else
		$role = 'user';

	return $role;

}

/*Get Users*/

function get_users($offset=0, $limit=10){

	global $db; 

	$sql = "SELECT * FROM `user`";

	$response = mysqli_query($db, $sql);

	$users['num_rows']=ceil($response->num_rows/$limit);

	$sql = "SELECT * FROM `user` LIMIT ".$offset.", ".$limit;

	$response = mysqli_query($db, $sql);
	while ($row = mysqli_fetch_assoc($response)) {
		$users['users'][]=$row;
	}
	 
	if($users)
		return (object)$users;

}


/*Check is Admin*/

function is_admin(){

	if(isset($_SESSION['admin']) && $_SESSION['admin']){
		return true;
	}
	return false;

}

/*Check is Shop Manager*/

function is_shop_manager(){

	if(isset($_SESSION['shop_manager']) && $_SESSION['shop_manager']){
		return true;
	}
	return false;

}

/*Check is user logged in*/

function is_user_logged_in(){

	if(isset($_SESSION['user']) || isset($_SESSION['admin']) || isset($_SESSION['shop_manager'])){
		return true;
	}
	return false;

}

/*Register user*/

function register_user($username, $email, $pass, $level=1){
	$error = array();
	if(!isset($username) || empty($username))
		$error['username'] = "Введіть ім'я користувача"; 
	if(!isset($email)  || empty($email))
		$error['user_email'] = "Введіть електронну адресу користувача";
	else
		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
			$error['user_email'] = "Перевірте електронну адресу користувача";
	if(!isset($pass) || empty($pass))
		$error['user_pass'] = "Введіть пароль користувача"; 

	global $db;
	if(count($error) == 0){
		$sql = "SELECT * FROM `user` WHERE `username` = '".filter_var($username, FILTER_SANITIZE_STRING)."' OR `user_email` ='".$email."'";
		$response = mysqli_query($db, $sql);

		if(property_exists($response, 'num_rows')){
			if($response->num_rows>0)
				$error['exists'] = "Користувач за таким ім'ям або електронною поштою вже зареєстрований"; 
		} 
	}
	if(count($error) == 0){

		$sql = "INSERT INTO `user` (username,
									user_email,
									user_pass, 
									level) 
							VALUES (
									'".filter_var($username, FILTER_SANITIZE_STRING)."',
									'".$email."',
									'".md5($pass)."',
									".filter_var($level, FILTER_VALIDATE_INT).")";
		$request = mysqli_query($db, $sql);
		if($request)
			return mysqli_insert_id($db);

	}else{
		return $error;
	}

}


/*Edit User*/

function edit_user($id, $username, $email, $pass, $level=1){

	if(!isset($id)){
		return false;
	}
	$error = array();
	if(!isset($username) || empty($username))
		$error['username'] = "Введіть ім'я користувача"; 
	if(!isset($email)  || empty($email))
		$error['user_email'] = "Введіть електронну адресу користувача";
	else
		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
			$error['user_email'] = "Перевірте електронну адресу користувача";	 

	global $db;

	if(count($error) == 0){
		$sql = "SELECT * FROM `user` WHERE `username` = '".filter_var($username, FILTER_SANITIZE_STRING)."' OR `user_email` ='".$email."'";
		$response = mysqli_query($db, $sql);

		if(property_exists($response, 'num_rows')){
			if($response->num_rows>0){
				$user = mysqli_fetch_assoc($response);
				if($user['id'] != $id)
					$error['exists'] = "Користувач за таким ім'ям або електронною поштою вже зареєстрований"; 
			}
		} 
	}
	if(count($error) == 0){
		if(!isset($pass) || empty($pass)){
			$sql = "UPDATE 	`user` SET `username`='".filter_var($username, FILTER_SANITIZE_STRING)."',
							`user_email`='".$email."',						 
							`level`=".filter_var($level, FILTER_VALIDATE_INT)." 
					WHERE `id`=".filter_var($id, FILTER_VALIDATE_INT);

		}else{
			$sql = "UPDATE 	`user` SET `username`='".filter_var($username, FILTER_SANITIZE_STRING)."',
							`user_email`='".$email."',
							`user_pass`='".md5($pass)."',
							`level`=".filter_var($level, FILTER_VALIDATE_INT)." 
					WHERE `id`=".filter_var($id, FILTER_VALIDATE_INT);
		}
		$request = mysqli_query($db, $sql);
		if($request)
			return (int)$id;
	}else{
		return $error;
	}
	

}

/*Delete User*/

function delete_user($id){

	if(!isset($id)){
		return false;
	}

	global $db;

	$sql = "DELETE FROM `user` WHERE `id` = ".filter_var($id, FILTER_VALIDATE_INT);
	$request = mysqli_query($db, $sql);
	if($request)
		return true;
	else
		return false;

}