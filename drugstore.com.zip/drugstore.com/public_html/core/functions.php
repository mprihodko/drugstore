<?php

if(defined("DEBUG") && DEBUG){
	ini_set('error_reporting', E_ALL);
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
}

/*Get Header File*/

function get_header(){
	if(file_exists(ABSPATH.'views/header.php')){
		include_once ABSPATH.'views/header.php';
	}else{
		exit('Не удается найти файл ' . ABSPATH .'views/header.php');
	}
}

/*Get Footer File*/

function get_footer(){
	if(file_exists(ABSPATH.'views/footer.php')){
		include_once ABSPATH.'views/footer.php';
	}else{
		exit('Не удается найти файл ' . ABSPATH .'views/footer.php');
	}
}

/*Pagination*/

function pagination($pages, $filter=null){

	$current = (isset($_GET['paged']))?(int)$_GET['paged'] : 1;
	for ($i=1; $i <= $pages; $i++) { 
		$active = '';
		if($i==$current)
			$active = 'disabled';
		if($filter == 'front'){
			$url = str_replace('page/'.$current.'/', "", $_SERVER['REQUEST_URI']);
			if($i==1)
				echo '<a href="'.$url.'" class="btn btn-default '.$active.' text-center" style="margin-left:5px;">'.$i.'</a>';
 			else
				echo '<a href="'.$url.'page/'.$i.'/" class="btn btn-default '.$active.' text-center" style="margin-left:5px;">'.$i.'</a>';
		}elseif($filter){
			echo '<a href="'.$filter.'&paged='.$i.'" class="btn btn-default '.$active.' text-center" style="margin-left:5px;">'.$i.'</a>';
		}else{
			echo '<a href="?paged='.$i.'" class="btn btn-default '.$active.' text-center" style="margin-left:5px;">'.$i.'</a>';
		}
	}

}

/*Display home url*/

function home_url($link=''){

	if(defined('HOME_URL')){
		echo HOME_URL.$link;
	}

}

/*get home url*/

function get_home_url($link=''){

	if(defined('HOME_URL')){
		return HOME_URL.$link;
	}

}

/*Get title*/

function the_title($echo = true){
	global $node;
	if(!$node)
		return;
	if($echo)
		echo $node->node_name;
	else
		return $node->node_name;
}

/*Enqueue Scripts*/

function enqueue_script($path, $place='header'){

	if($place == 'header'){

		echo '<script type="text/javascript" src="'.$path.'"></script>';

	}elseif($place == 'footer'){

		echo '<script type="text/javascript" src="'.$path.'"></script>';

	}

}


/*Enqueue Styles*/

function enqueue_style($path){

	echo '<link rel="stylesheet" type="text/css" href="'.$path.'">';	

}

/*Write header scripts*/

function head(){
	enqueue_style(get_home_url().'assets/css/normalize.css');
	enqueue_style(get_home_url().'assets/css/font-awesome.min.css');
	enqueue_style(get_home_url().'assets/css/bootstrap.min.css');
	enqueue_style(get_home_url().'assets/css/fonts.css');
	enqueue_style(get_home_url().'assets/css/pharmacy.css');
	enqueue_script(get_home_url().'assets/js/jquery-1.11.1.min.js');
	enqueue_script(get_home_url().'assets/js/bootstrap.min.js');
	enqueue_script(get_home_url().'assets/js/uisearch.js');
	enqueue_script(get_home_url().'assets/js/jQuery.scrollSpeed.js');
	if(is_user_logged_in()){
		enqueue_script(get_home_url().'assets/js/cart.js');
	}
	

}

/*Write footer scripts*/

function foot(){
	enqueue_script(get_home_url().'assets/js/classie.js');
	enqueue_script(get_home_url().'assets/js/uisearch.js');
}



require_once 'admin-controll.php';
require_once 'user.php';
require_once 'categories.php';
require_once 'product.php';
require_once 'node.php';

function add_order($data){	

	$order_id = save_node('Замовлення', 'private', 'order');
	if(is_int($order_id)){
		update_node($order_id, 'Замовлення #'.$order_id, 'private', 'order');	
		foreach ($data['product'] as $key => $value) {
			$order_items[$key]['product'] = $value;
			$order_items[$key]['qty'] = $data['qty'][$key];
			$order_items[$key]['office'] = $data['office'][$key];
		}
		add_node_meta($order_id, "order_items", json_encode($order_items));	
		add_node_meta($order_id, "order_status", 'new');
		add_node_meta($order_id, "order_user", $data['user_id']);

	}

}

function get_orders($status='new'){

	global $db;

	$sql = "SELECT `node_id` FROM `nodes_meta` WHERE `meta_key` = 'order_status' AND `meta_value` = '".$status."'";

	$request = mysqli_query($db, $sql);

	if($request){
		while ($row = mysqli_fetch_assoc($request)) {
			$orders[]=$row['node_id'];
		}
	}
	$sql ="SELECT * FROM `nodes` WHERE `id` IN (".implode(", ", $orders).")";
	$request = mysqli_query($db, $sql);

	if($request){
		while ($row = mysqli_fetch_assoc($request)) {
			$order_list['orders'][]=$row;
		}
	}
	return (object)$order_list;

}