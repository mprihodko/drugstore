<?php

/*Init admin*/


function admin_init(){
	if(is_admin() || is_shop_manager()){

		get_user();
		return true;

	}else{
		if(is_user_logged_in()){
			return false;
		}
		if(isset($_POST['action'])){
			if($_POST['action'] != 'user_login')
				return;
			$log = filter_var($_POST['log'], FILTER_VALIDATE_EMAIL);
			if(!$log){
				$log = filter_var($_POST['log'], FILTER_SANITIZE_STRING);
			}
			$pwd = filter_var($_POST['pwd'], FILTER_SANITIZE_STRING);
			$foreve = filter_var($_POST['rememberme'], FILTER_SANITIZE_STRING);
			login_user($log, $pwd, $foreve);
			return false;
		}else{
			include '../login.php';
			return false;
		}

	}
}

/*Display admin url*/

function admin_url($link=''){

	echo get_home_url('admin/'.$link);

}

/*get_admin url*/

function get_admin_url($link=''){

	return get_home_url('admin/'.$link);

}

/*Get Header File*/

function admin_header(){
	if(file_exists(ABSPATH.'admin/header.php')){
		include_once ABSPATH.'admin/header.php';
	}else{
		exit('Не удается найти файл ' . ABSPATH .'admin/header.php');
	}
}

/*Get Footer File*/

function admin_footer(){
	if(file_exists(ABSPATH.'admin/footer.php')){
		include_once ABSPATH.'admin/footer.php';
	}else{
		exit('Не удается найти файл ' . ABSPATH .'admin/footer.php');
	}
}

/* User Roles Admin menu */

function admin_menu(){

	$role = curent_user_role();
	if($role === 'admin'){

		return array(

			'index'		=> array( 'access' => true,
								  'name' => 'Керування',
								  'icon' => 'fa-dashboard'
								),
			'users'		=> array( 'access' => true,
								  'name' => 'Користувачі',
								  'icon' => 'fa-users'
								),
			'ecommerce'	=> array('access' => true,
								 'name' => 'Продукція',								 
								 'icon' => 'fa-shopping-cart',
								 'subitems' => array(
								 		'products' => array('name'=>'Ліки', 'access'=> true),
								 		'offices' => array('name'=>'Відділення', 'access'=> true),
								 		'categories' => array('name'=>'Категорії', 'access'=> true),
								)
							),
			'orders'	=> array('access' => true,
							 	 'name' => 'Замовлення',
							 	 'icon' => 'fa-truck',
								 'subitems' => array(
								 		'new' => array('name'=>'Нові', 'access'=> true),
								 		'complete' => array('name'=>'Виконані', 'access'=> true),
								 		'hold' => array('name'=>'В обробці', 'access'=> true),
								)
							),
		);

	}
	if($role === 'shop_manager'){

		return array(

			'index'		=> array('access' => true,
								 'name' => 'Керування',
								 'icon' => 'fa-dashboard'
								),
			'users'		=> array('access' => false,
								 'name' => 'Користувачі',
								 'icon' => 'fa-users'								 
								),
			'ecommerce'	=> array('access' => true,
								 'name' => 'Продукція',
								 'icon' => 'fa-shopping-cart',
								 'subitems' => array(
								 		'products' => array('name'=>'Ліки', 'access'=> true),
								 		'offices' => array('name'=>'Відділення', 'access'=> false),
								 		'categories' => array('name'=>'Категорії', 'access'=> true),
								)
							),
			'orders'	=> array('access' => true,
							 	 'name' => 'Замовлення',
							 	 'icon' => 'fa-truck',
								 'subitems' => array(
								 		'new' => array('name'=>'Нові', 'access'=> true),
								 		'complete' => array('name'=>'Виконані', 'access'=> true),
								 		'hold' => array('name'=>'В обробці', 'access'=> true),
								)
							),
			'pages'		=> array('access' => false,
								 'name' => 'Сторінки',
								 'icon' => 'fa-file'
								),


		);

	}

}