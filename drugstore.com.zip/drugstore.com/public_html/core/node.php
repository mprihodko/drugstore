<?php 

function save_node($node_name, $node_status, $node_type, $node_content=null){

	if(!$node_name)
		$node_name = 'Без назви';

	if(!$node_status)
		$node_status = 'draft';

	if(!$node_type)
		$node_type = 'page';

	global $db;

	$sql = "INSERT INTO `nodes` (node_name, node_status, node_type, node_content)
			VALUES('".filter_var($node_name, FILTER_SANITIZE_STRING)."', '".filter_var($node_status, FILTER_SANITIZE_STRING)."', '".filter_var($node_type, FILTER_SANITIZE_STRING)."', '".filter_var($node_content, FILTER_SANITIZE_STRING)."')";
	$request = mysqli_query($db, $sql);
	if($request)
		return mysqli_insert_id($db);
	else
		return $error['undefined'] = "Сталася невідома помилка";

}

function update_node($id, $node_name, $node_status, $node_type, $node_content=null){

	if(!$id)
		return false;

	if(!$node_name)
		$node_name = 'Без назви';

	if(!$node_status)
		$node_status = 'draft';

	if(!$node_type)
		$node_type = 'page';

	global $db;

	$sql = "UPDATE `nodes` SET 	`node_name` = '".filter_var($node_name, FILTER_SANITIZE_STRING)."',
	 						    `node_status` = '".filter_var($node_status, FILTER_SANITIZE_STRING)."',
	 						    `node_type` = '".filter_var($node_type, FILTER_SANITIZE_STRING)."',
	 						    `node_content` = '".filter_var($node_content, FILTER_SANITIZE_STRING)."'
			WHERE `id` = ".$id;
	$request = mysqli_query($db, $sql);
	if($request)
		return (int)$id;
	else
		return $error['undefined'] = "Сталася невідома помилка";

}

function delete_node($node_id){

	if(!$node_id)
		return false;

	global $db;

	$sql = "DELETE FROM `nodes` WHERE `id`=".$node_id;
	
	$request = mysqli_query($db, $sql);
	if($request)
		return true;
	else
		return $error['undefined'] = "Сталася невідома помилка";
}

function get_node($id){

	if(!$id)
		return;

	global $db;

	$sql ="SELECT * FROM `nodes` WHERE `id`=".$id;

	$request = mysqli_query($db, $sql);
	if($request)
		return mysqli_fetch_assoc($request);
	else
		return false;

}

function add_node_meta($node_id, $key, $value){

	global $db;

	if(!$node_id || !$key || !$value)
		return false;

	$sql = "INSERT INTO `nodes_meta` (node_id, meta_key, meta_value) VALUES(".$node_id.", '".filter_var($key, FILTER_SANITIZE_STRING)."', '".$value."')";

	$request = mysqli_query($db, $sql);
	if($request)
		return mysqli_insert_id($db);
	else
		return $error['undefined'] = "Сталася невідома помилка";


}

function get_node_meta($node_id, $key){

	global $db;

	if( !$node_id || !$key )
		return false;

	$sql = "SELECT `meta_value` FROM `nodes_meta` WHERE `node_id` = ".$node_id." AND `meta_key`='".filter_var($key, FILTER_SANITIZE_STRING)."'";
	$request = mysqli_query($db, $sql);
	$value = mysqli_fetch_assoc($request);
	if($value)
		return $value['meta_value'];
	else
		return false;


}

function update_node_meta($node_id, $key, $value){

	global $db;

	if(!$node_id || !$key || !$value)
		return false;
	
	if(!get_node_meta($node_id, $key)){
		add_node_meta($node_id, $key, $value);
	}else{
		$sql = "UPDATE `nodes_meta` SET `meta_value` = '".$value."' WHERE `node_id`=".$node_id." AND `meta_key`='".filter_var($key, FILTER_SANITIZE_STRING)."'";

		$request = mysqli_query($db, $sql);
		if($request)
			return mysqli_insert_id($db);
		else
			return $error['undefined'] = "Сталася невідома помилка";
	}
}

function delete_node_meta($node_id, $key=null){

	if(!$node_id)
		return false;

	global $db;

	$sql = "DELETE FROM `nodes_meta` WHERE `node_id`=".$node_id;
	if($key)
		$sql .= " AND `meta_key`='".$key."'";
	$request = mysqli_query($db, $sql);
	if($request)
		return true;
	else
		return $error['undefined'] = "Сталася невідома помилка";
}