</div>
<footer>
	<img class="foot_logo"  src="<?php home_url('img/logo.png'); ?>" alt="logo">
	<p class="foot_logo_text">
		<span class="foot_top_logo">
			<a href="#">Аптека «Барвинок»</a>
		</span>
		<br>
		<span class="foot_bot_logo"> <i>Ліки за соціальними цінами</i>
		</span>
	</p>
	<ul class="footer_social">
		<li>
			<a href="#"> <i class="fa fa-facebook" aria-hidden="true"></i>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-twitter" aria-hidden="true"></i>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-google-plus" aria-hidden="true"></i>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-instagram" aria-hidden="true"></i>
			</a>
		</li>
	</ul>
	<div class="foot_main_menu">
		<div class="foot_main_menu_item">
				<a href="<?php home_url('/')?>">Головна</a>
		</div>
		<div class="foot_main_menu_item">
			<a href="<?php home_url('about/')?>">Про аптеку</a>
		</div>
		<div class="foot_main_menu_item">
			<a href="<?php home_url('catalog/')?>">Каталог Ліків</a>
		</div>
		<?php if(is_user_logged_in()): ?>
		<div class="foot_main_menu_item">
			<a href="<?php home_url('index.php?logout=true') ?>">Вийти</a>
		</div>
		<?php else: ?>
		<div class="foot_main_menu_item">
			<a href="<?php home_url('registration/')?>">Реєстрація/Вхід</a>
		</div>
		<?php endif;?>
	</div>	
	<div class="container-fluid copyright">
		<p>© 2016 Аптека «Барвинок». Всі права захищені.</p>
	</div>
</footer>

<div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="cart" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Кошик</h4>
      </div>
      <div class="modal-body">
      		
      		<table class="table table-hover" id="cartTable">

                <thead>
                    
                    <tr>
	                    <th width='10%'></th>
	                    <th width='30%'>Назва</th>
	                    <th width='15%'>Кількість <br> <b>(од.)</b></th>
	                    <th width='20%'>Ціна <br><b>(грн.)</b></th>	
	                    <th width='20%'>Загальна Ціна <br><b>(грн.)</b></th>	
	                    <th width='5%'></th>	                    
                	</tr>

                </thead>
                <tbody>
                	
                </tbody>
            </table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрити</button>
        <a href="<?php home_url('checkout/'); ?>" class="btn btn-primary disabled" id="checkoutButton">Перейти до оформлення</a>
      </div>
    </div>
  </div>
</div>
<?php foot(); ?>
</body>
</html>