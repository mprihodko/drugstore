
<div class="banner banner-category">
    <p class="main_diskont"><span style="white-space: nowrap;"><?php echo $node_name?></span></p>
</div>
<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container category">
        <div class="breadCrumbs">
            <a href="<?php echo home_url(); ?>">Головна</a> <b> / </b>
            <a href="#" onclick="window.history.back()" >До Категорії</a> <b> / </b>
            <span><?php echo (isset($node_name)? $node_name : 'Product')?></span>
        </div>
        <div class="row">
            <div class="col-md-5 clearfix image-mains">
                <div class="images">
                    <div class="woocommerce-main-image">
                        <a href="#" class="cloud-zoom featured-image">
                            <img src="<?php echo (isset($thumb)? $thumb : '')?>" class="attachment-shop_single size-shop_single wp-post-image" id="image"></a>
                    </div>
                </div>
            </div>
            <div class="col-md-7 information">
                <div class="summary entry-summary ">
                    <h3 class="product_title">
                        <?php echo (isset($node_name)? $node_name : 'Product')?>            
                    </h3>
                    <div>
                        <p class="price">
                            <span class="woocommerce-Price-amount amount"> 
                                <del>
                                    <?php echo (isset($price)? number_format($price+($price*15/100), 2, '.', ' ') : ''); ?>грн.
                                </del>
                            </span>
                            <span class="woocommerce-Price-currencySymbol">
                                <?php echo (isset($price)? $price : ''); ?> грн.
                            </span>
                        </p>
                    </div>
                    <div class="product_meta">
                        <span class="posted_in">Категорії:</span>
                        <?php if (is_array($categories) && count($categories)): ?>
                            <?php foreach ($categories as $category_id) : ?>
                                <a href="<?php home_url('category/'.$category_id) ?>" rel="tag">
                                    <?php 
                                        $category = get_category($category_id);
                                        echo (isset($category['name'])? $category['name']: '');
                                      ?>
                                    </a>
                             <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                     <div class="product_meta">
                        <span class="posted_in">Відділення:</span>
                        <?php if (is_array($offices) && count($offices)): ?>
                            <?php foreach ($offices as $office_id) : ?>
                                <a href="<?php home_url('office/'.$office_id) ?>" rel="tag">
                                    <?php 
                                        $office = get_category($office_id);
                                        echo (isset($office['name'])? $office['name']: '');
                                      ?>
                                    </a>
                             <?php endforeach; ?>
                        <?php else: ?>
                            <h3>Ліки відсутні на відділеннях</h3>
                        <?php endif; ?>
                    </div>                   
                    <hr>
                    <?php if(is_user_logged_in()): ?>
                        <div class="quantity buttons_added">
                            <input type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" id="qty" class="input-text qty text" size="4" pattern="[0-9]*" inputmode="numeric"></div>
                        <input type="hidden" name="add-to-cart" value="<?php echo $id?>">
                        <button type="button" class="single_add_to_cart_button  alt btn btn-info <?php echo (is_array($offices) && count($offices))? '': 'disabled'?>" data-product = "<?php echo $id; ?>">Додати в кошик</button>
                         <?php echo (is_array($offices) && count($offices))? '': '<br><br><small class="text-danger">Нажаль ліків немає на жодному відділенні!</small>'?>
                    <?php else: ?>
                        <h3>Щоб купити ліки необхідно <a href="<?php home_url('registration/') ?>">авторизуватися</a> на нашому сайті</h3>
                    <?php endif; ?>
                    <hr>
                </div>
            </div>
            <div class="container decrip">
                <div class="row">
                    <div class=" col-md-10 panel-heading">
                        <div id="accordion-list-description" class="panel-collapse collapse in">
                            <div class="panel-title">
                                <h3>Інструкція</h3>                                
                            </div>
                            <div class="panel-body">
                                <p class="product-description desc2">
                                     <?php echo (isset($node_content)? $node_content : '') ?>
                                </p>                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>