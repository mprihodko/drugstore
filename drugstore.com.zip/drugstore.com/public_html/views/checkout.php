<div class="banner banner-category">
    <p class="main_diskont"><span style="white-space: nowrap;">Сторінка Оформлення</span></p>
</div>
<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container category">
        <div class="row">
			<section class="first_step checkoutStep col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1>
					<small>Оберіть Відділення</small>
				</h1>
				<form action="" method="POST">
					<input type="hidden" name="action" value="new_order">
					<input type="hidden" name="user_id" value="<?php echo $_SESSION['user_data']['id'] ?>">
					<table class="table table-hover" id="checkoutItemsTable">
						<thead>
							<tr>				           
					            <th width='30%' colspan="2">Назва</th>
					            <th width='15%'>Кількість <br> <b>(од.)</b></th>
					            <th width='15%'>Ціна <br><b>(грн.)</b></th>	
					            <th width='15%'>Загальна Ціна <br><b>(грн.)</b></th>
					            <th width='20%'>Відділення</th>	
					            <th width='5%'></th>	                    
					    	</tr>
						</thead>
						<tbody>
							<?php if(isset($_SESSION['cart']) && count($_SESSION['cart'])): ?>
								<?php foreach( $_SESSION['cart'] as $product_id => $qty ): $product = get_product($product_id); ?>
									<tr class="checkout-row" id="product-row-<?php echo $product_id; ?>">
										<td width='10%'><img src="<?php echo $product['thumb']; ?>" style='max-width:100%;'></td>
										<td width='20%'>
											<?php echo $product['node_name']; ?>
											<input type="hidden" name="product[]" value="<?php echo $product_id;?>">
											<input type="hidden" name="qty[]" value="<?php echo $qty;?>">
										</td>
										<td><?php echo $qty; ?></td>
										<td><?php echo number_format((float)$product['price'], 2, ".", " "); ?></td>
										<td><?php echo number_format((float)$product['price']*$qty, 2, ".", " "); ?></td>
										<td>
											<select name="office[]" required>
												<?php if(is_array($product['offices'])): 
														foreach($product['offices'] as $category_id): 
															$category = get_category($category_id);
		                                       	?>
														<option value="<?php echo $category_id; ?>"><?php echo (isset($category['name'])? $category['name']: ''); ?></option>

												<?php 	endforeach;
													  endif; ?>		
											</select>
										</td>
										<td><button data-id="<?php echo $product_id; ?>" class='btn btn-danger delCartItem'><i class='fa fa-times'></i></button></td>

									</tr>
								<?php endforeach; ?>
							<?php else: ?>
							<?php endif;?>
						</tbody>
					</table>
					<div class="pull-right">
						<input type="submit" name="checkout" class="btn btn-lg btn-info" value="Замовити">
					</div>
				</form>
			</section>
		</div>
	</div>
</div>