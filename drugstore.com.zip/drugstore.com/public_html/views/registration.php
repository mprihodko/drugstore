
    <div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
        
        
        <div class="container signin ">
            <div class="tabs">
                <div class="tab active" data-tab="f-log">Вхід</div>
                <div class="tab" data-tab="f-reg" >Реєстрація</div>
            </div>
            <form class="form-signin f-log tab-content active" action="" role="form" method="POST" autocomplete="false">
                <input type="hidden" name="action" value="user_login">
                <h2 class="form-signin-heading"><?php echo (isset($message)?  $message : '' )?></h2>
                <input type="text" class="form-control my_form-control" placeholder="Адресa эл. пошти" name="log" required>
                <input type="password" class="form-control my_form-control" placeholder="Пароль" name="pwd" required>
                <div class="checkbox">
                    <label>                        
                        <input type="checkbox" name="rememberme"  value="foreve"> <span class="pharm_rem_me">Запам'ятати мене</span></os-p>
                    </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block" type="submit" data-replace-tmp-key="b6d4223e60986fa4c9af77ee5f7149c5">
                    <os-p key="b6d4223e60986fa4c9af77ee5f7149c5">Увійти</os-p>
                </button>
            </form>
      
            <form class="form-signin f-reg tab-content" role="form" action="" method="POST">
                <h2 class="form-signin-heading">Зареєструйтеся, будь ласка </h2>
                <input type="hidden" name="action" value="user_registration">
                <input type="email" name = "email" class="form-control my_form-control" placeholder="Адресa эл. пошти" required>
                <input type="password" name="password" class="form-control my_form-control" placeholder="Пароль" required>
                <input type="text" name="username" class="form-control my_form-control" placeholder="Логін" required>
                <button class="btn btn-lg btn-primary btn-block" type="submit">
                    Зареєструватися 
                </button>
            </form>
        </div>
    </div>

    <script type="text/javascript">
        $ = jQuery;
        $(".tabs .tab").click(function(){
            if($(this).hasClass('active')){
                return;
            }else{
                $(".tabs .tab").removeClass('active');
                $(this).addClass('active');
                $('.tab-content').removeClass('active');
                var tab = $(this).data('tab');
                $('.'+tab).addClass('active');
            }
        });
    </script>
 
