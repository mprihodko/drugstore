
<div class="banner banner-category">
    <p class="main_diskont"><span style="white-space: nowrap;"><?php echo $category['name']?></span></p>
</div>
<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="container category">
        <div class="breadCrumbs">
            <a href="<?php echo home_url(); ?>">Головна</a> <b> / </b>
            <a href="#" onclick="window.history.back()" >До Каталогу</a> <b> / </b>
            <span><?php echo $category['name']?></span>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 ">
                <h3 style="color:#2aa1cc;" ><?php echo $category['name']?></h3>
                <div class="line"></div>
                <p class="text-center"><?php echo $category['description']?></p>
            </div>
            <?php if(property_exists($products, 'products') && is_array($products->products)): ?>
                
                <?php foreach ($products->products as $product): ?>

                    <?php 
                        $prod = get_product($product['node_id']);
                    ?>


                    <div class="col-md-4 col-sm-4 col-xs-6 product_block">
                        <div class="category_img_hiden">    
                            <div class="category_img" style="background-image: url(<?php echo $prod['thumb']; ?>); background-size: cover; background-position: center; background-repeat: no-repeat;">
                            </div>
                            <h3 class="category_price"><?php echo $prod['node_name']; ?>
                                <br><span class="pull-right price">Ціна: <?php echo $prod['price']; ?>грн</span>
                            </h3>
                            <a class="product_link" href="<?php home_url('product/'.$prod['id']);?>"></a>
                         </div>  
                    </div>


                <?php endforeach; ?>
            <?php else: ?>
                <div class="line"></div>
                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                    <h1 style="font-size: 70px;">Вибачте <i class="fa fa-angellist fa-6 " style="opacity:0.5; font-size: 200px;" aria-hidden="true"></i></h1>
                    <h3 style="margin-top: 20px;">Нажаль в категорії ліки відсутні</h3>
                </div>
            <?php endif; ?>
         
            <div class="clearfix"></div>
            
            <?php if(property_exists($products, 'products') && is_array($products->products)): ?>
                <?php if(property_exists($products, 'num_rows') && (int)$products->num_rows>1): ?>
                    <nav class="category_nav">
                        <?php echo pagination($products->num_rows, 'front');?>
                  
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
