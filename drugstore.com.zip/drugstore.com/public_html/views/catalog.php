
<div class="banner banner-category">
	<p class="main_diskont"><span>Каталог Ліків</span></p>
</div>
<div id="main-content" class="archive-shop col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="container category">
		<div class="breadCrumbs">
            <a href="<?php echo home_url(); ?>">Головна</a> <b> / </b>            
            <span>Каталог</span>
        </div>
		<?php
		$paged = (isset($_GET['paged'])? $_GET['paged']: 1);

		$categories = get_categories(($paged-1)*9, 9, 'category');
		if($categories && $categories->num_rows>0):
			$i = 0;
			foreach ($categories->categories as $category):  $i++;

		?>
				<div class="col-md-4">
					<div class="bc_category_block">
						<h3 class="bc_category_title">
							<a href="<?php home_url('category/'. $category['id'] .'/'); ?>">
								<?php echo $category['name']; ?>
							</a>
						</h3>
						<p class="bc_category_desc">
							<?php echo (strlen($category['description'])>300)? trim(mb_substr($category['description'], 0, 300)) : $category['description']; ?>...
						</p>
						<span class="bc_go_to_category">
							<a href="<?php home_url('category/'. $category['id'] .'/'); ?>">Перейти</a>
						</span>
					</div>
				</div>
				<?php if($i%3==0): ?>
				<div class="clearfix"></div>		
		<?php   endif;

			endforeach;
		endif;
		?>

	</div>
</div> 
