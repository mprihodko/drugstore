<?php 
require_once('config.php' );
if(is_user_logged_in() && is_admin()){
	header('Location: '.get_home_url('admin'));
}elseif(is_user_logged_in()){
	header('Location: '.get_home_url());
}else{
?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="<?php the_title(); ?>">
	<title>Логiн</title>
	<link rel="shortcut icon" href="<?php home_url('img/favicon.png') ?>">
	<?php head(); ?>
</head>

<body class="login login-action-login wp-core-ui  locale-en-us">
		<div class="flex">
		<div id="login">
			<form name="loginform" id="loginform" action="<?php home_url('admin/index.php'); ?>" method="post">
				<input type="hidden" name="action" value="user_login">
				<div class="form_in">
				<p>
					<label for="user_login">Ім'я користувача або Email<br>
					<input type="text" name="log" id="user_login" class="input" value="" size="23"></label>
				</p>
				<p>
					<label for="user_pass">Пароль<br>
					<input type="password" name="pwd" id="user_pass" class="input" value="" size="23"></label>
				</p>
				<p class="forgetmenot">
					<label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"> Запам'ятати мене</label>
				</p>
				<p class="submit">
					<input type="submit" name="submit" id="wp-submit" class="button button-primary button-large" value="Увiйти">			
				</p>
				</div>
			</form>		
		</div>
	</div>	
</body>
</html>
<?php }