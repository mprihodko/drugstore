<?php 

/*
*
*	Load website core
*	v.1.0
*
*/

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require( dirname( __FILE__ ) . '/config.php' );
if(file_exists(ABSPATH . 'views/index.php')){
	require( ABSPATH . 'views/index.php' );
}else{
	exit('Не удается найти файл ' . ABSPATH .'views/index.php');
}
