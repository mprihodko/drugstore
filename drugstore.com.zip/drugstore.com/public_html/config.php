<?php 


/** MySQL database name */
define('DB_NAME', 'apteka');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '123456');

/** MySQL hostname */
define('DB_HOST', 'localhost');

define('HOME_URL', $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/');

define('DEBUG', true);

if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

if(file_exists(ABSPATH . 'core/functions.php')){
	require_once(ABSPATH . 'core/functions.php');
}else{
	exit('Не удается найти файл ' . ABSPATH .'core/functions.php');
}


/* Database Connect */

$GLOBALS['db'] = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
session_start();

if(isset($_COOKIE['foreve'])){
	$user_data = (array)json_decode($_COOKIE['foreve']);
	$level = (int)$user_data['level'];
	$_SESSION['admin'] = ($level>5)? true : false;	
	$_SESSION['shop_manager'] = ($level>1)? true : false;	;
	$_SESSION['user'] = ($level==1)? true : false;	;	
	$_SESSION['user_data']['id'] = $user_data['id'];
	$_SESSION['user_data']['username'] = $user_data['username'];
	$_SESSION['user_data']['user_email'] = $user_data['user_email'];
	$_SESSION['user_data']['level'] = $user_data['level'];
}
if (!$GLOBALS['db']) {
    echo "Ошибка: Невозможно установить соединение с MySQL." . PHP_EOL;
    echo "Код ошибки errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Текст ошибки error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}