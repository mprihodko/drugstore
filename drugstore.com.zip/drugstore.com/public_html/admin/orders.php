<?php
require_once('../config.php' );
admin_init();

admin_header();
$order_list = get_orders();
 
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Замовлення 
        </h1>
        <ol class="breadcrumb">
        	<li >
                <a href="<?php admin_url()?>"><i class="fa fa-dashboard"></i> Керування </a>
            </li>           
        	<li class="active">
                <i class="fa fa-pencil"></i> Новi Замовлення
            </li>	       
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row clearfix ">

	<div class="col-lg-12">
		<!-- Render user table -->
		<table class="table table-hover">

			<!-- table header -->
			<thead>
				<th>ID</th>
				<th>Замовлені Ліки</th>			 
				<th>Дії</th>       			      			
			</thead>

			<!-- table body -->
			<tbody>

				<?php	foreach ($order_list->orders as $order) : extract($order); ?>

	    			<tr class="user-<?php echo $username; ?> " id="user-<?php echo $id; ?>">
	        			<td><?php echo $node_name; ?></td>
	        			<td></td>
	        			<td>
	        				<a href="?action=edit&id=<?php echo $id; ?>" class="btn btn-success fa fa-pencil"></a>
	        				<?php if($id === '1'){ ?>
	        					<a href="?action=delete&id=<?php echo $id; ?>" class="btn btn-danger fa fa-trash disabled"></a>
	        				<?php }else{ ?>
	        					<a href="?action=delete&id=<?php echo $id; ?>" class="btn btn-danger fa fa-trash "></a>
	        				<?php } ?>
	        			</td>
	    			</tr>

				<?php endforeach; ?>

			</tbody>
		</table>
	<!-- Render user table -->


	</div>
</div>



<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery(".nav-orders").addClass('active');
			jQuery("#orders-subitems").addClass('in');
			<?php if(isset($_GET['page'])): ?>
				jQuery(".sub-<?php echo $_GET['page']?> a").addClass('active');
			<?php endif; ?>
		})
	</script>
<?php

admin_footer();

?>