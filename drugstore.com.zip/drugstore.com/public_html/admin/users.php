<?php
require_once('../config.php' );
admin_init();
/*Handle User Actions*/
if(isset($_POST['action'])){
	extract($_POST);
	switch ($action) {
		case 'create':
			$error = $user_id = register_user($username, $user_email, $user_pass, $level);
			if(is_int($user_id)){
				header('Location: '.get_admin_url('users.php'));
			}else{
				admin_header();
				include 'user/form.phtml';
				echo 	'<script type="text/javascript">
							jQuery(document).ready(function(){
								jQuery(".nav-users").addClass("active");
							})
						</script>';

				admin_footer();
				die;
			}
			break;
		case 'edit':
			$error = $user_id = edit_user($id, $username, $user_email, $user_pass, $level);
			if(is_int($user_id)){
				header('Location: '.get_admin_url('users.php'));
			}else{
				extract($_POST);
				admin_header();
				include 'user/form.phtml';
				echo 	'<script type="text/javascript">
							jQuery(document).ready(function(){
								jQuery(".nav-users").addClass("active");
							})
						</script>';

				admin_footer();
				die;
			}
			break;	
	}
}
/*Load Admin Pages*/
$action = (isset($_GET['action']))? $_GET['action'] : '';       
switch ($action) {
	case 'create':
		admin_header();
		include 'user/form.phtml';
		break;
	case 'edit':
		if(isset($_GET['id']))
			$user_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);		
		$user_data=get_user($user_id);
		admin_header();
		include 'user/form.phtml';
		break;
	case 'delete':
		if(isset($_GET['id']))
			$user_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
		if(!delete_user($user_id))
			$error['delete'] = 'Сталася невідома помилка';
		$limit = 10;
		$paged = 1;
		if(isset($_GET['paged']))
			$paged = $_GET['paged'];		
		if(isset($paged))
			$offset = ($paged - 1) * $limit;		
		$user_list = get_users($offset, $limit);
		admin_header();
		include 'user/index.phtml';		
		break;
	default:
		$limit = 10;
		$paged = 1;
		if(isset($_GET['paged']))
			$paged = $_GET['paged'];		
		if(isset($paged))
			$offset = ($paged - 1) * $limit;		
		$user_list = get_users($offset, $limit);
		admin_header();
		include 'user/index.phtml';		
		break;
}
?>

        
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery(".nav-users").addClass('active');
	})
</script>
<?php

admin_footer();

?>