<?php 

require_once('../config.php' );

if(isset($_REQUEST['action']) && $action = $_REQUEST['action']){

	switch ($action) {
		case 'add_to_cart':
			if(is_user_logged_in()){
				if(isset($_SESSION['cart'][$_REQUEST['id']])){
					$qty = (int)$_SESSION['cart'][$_REQUEST['id']] + (int)$_REQUEST['qty'];
				}else{
					$qty = (int)$_REQUEST['qty'];
				}
				$_SESSION['cart'][$_REQUEST['id']] = $qty ;
				die;
			}
			break;
		case 'render_cart':
			if(isset($_SESSION['cart']) && is_array($_SESSION['cart']) ){
				$total  = 0;
				$output = '';
				foreach ($_SESSION['cart'] as $product_id => $qty) {
					$product = get_product($product_id);
					$total +=(float)$product['price']*$qty;
					$output .= "
					<tr id='item-".$product_id."'>
						<td ><img src=".$product['thumb']." style='max-width:100%;'></td>
						<td>".$product['node_name']."</td>
						<td>".$qty."</td>
						<td>".number_format((float)$product['price'], 2, ".", " ")."</td>
						<td>".number_format((float)$product['price']*$qty, 2, ".", " ")."</td>
						<td><button data-id=".$product_id." class='btn btn-xs btn-danger delCartItem'><i class='fa fa-times'></i></button></td>
					</tr>";
				}
				$output .= "
					<tr id='totalPriceRow'>
						<td colspan='4'><strong>Загальна Сума :</strong></td>
					 
						<td id='cartTotal'>".number_format($total, 2, ".", " ")."</td>
						 
					</tr>";
				echo json_encode(array('html' => $output, 'total'=>number_format($total, 2, ".", " "), "checkout"=>true ) );
				die;
			}else{
				$output = "
				<tr id='totalPriceRow'>
					<td colspan='4'><strong>Ваш Кошик Порожній!</strong></td>	
				</tr>";
				echo json_encode(array('html' => $output, 'total'=>number_format(0, 2, ".", " "), "checkout"=>false ) );
			}

			break;
		case 'delete_from_cart':
			if(isset($_SESSION['cart']) && is_array($_SESSION['cart']) ){
				if(isset($_SESSION['cart'][$_REQUEST['id']]))
					unset($_SESSION['cart'][$_REQUEST['id']]);
				die;
			}
			break;
		case 'clear_cart':
			if(isset($_SESSION['cart'])){
				unset($_SESSION['cart']);
			}
			break;
		default:
			# code...
			break;
	}

}