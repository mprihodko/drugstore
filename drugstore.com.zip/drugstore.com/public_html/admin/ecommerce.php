<?php
require_once('../config.php' );

admin_init();

if(isset($_POST['action'])){
	extract($_POST);	

	switch ($action) {

		case 'add_category':
			$error = $category_id = add_category($name, $description, $taxonomy);
			if(is_int($category_id)){
				header('Location: '.get_admin_url('ecommerce.php?page=categories'));
			}else{		
				admin_header();
				include 'ecommerce/categories.php';
				echo '	<script type="text/javascript">

							jQuery(document).ready(function(){
								jQuery(".nav-ecommerce").addClass("active");
								jQuery("#ecommerce-subitems").addClass("in");
								<?php if(isset($_GET["page"])): ?>
									jQuery(".sub-<?php echo $_GET["page"]?> a").addClass("active");
								<?php endif; ?>
							})

						</script>';
				admin_footer();
				die;
			}
			break;
		case 'edit_category':
			$error = $category_id = edit_category($id, $name, $description);
			if(is_int($category_id)){
				header('Location: '.get_admin_url('ecommerce.php?page=categories'));
			}else{		
				admin_header();				 
				include 'ecommerce/categories.php';
				echo '	<script type="text/javascript">

							jQuery(document).ready(function(){
								jQuery(".nav-ecommerce").addClass("active");
								jQuery("#ecommerce-subitems").addClass("in");
								<?php if(isset($_GET["page"])): ?>
									jQuery(".sub-<?php echo $_GET["page"]?> a").addClass("active");
								<?php endif; ?>
							})

						</script>';
				admin_footer();
				die;
			}
			break;
		case 'add_product':
			$error = $product_id = save_node($node_name, $node_status, $node_type, $node_content);			
			if(is_int($product_id)){
				if(isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0){
					$error = $thumb_id = save_node(get_home_url().'img/'.$product_id.'-'.$_FILES['thumbnail']['name'], 'publish', 'attachment');	
					if(is_int($thumb_id)){	
						move_uploaded_file($_FILES['thumbnail']['tmp_name'], ABSPATH.'img/'.$product_id.'-'.$_FILES['thumbnail']['name']);
						add_node_meta($product_id, 'product_thumb', $thumb_id);
					}
				}
				add_node_meta($product_id, 'category', serialize($category));
				add_node_meta($product_id, 'office', serialize($office));
				add_node_meta($product_id, 'product_price', $product_price);
				header('Location: '.get_admin_url('ecommerce.php?page=products'));
			}else{
				var_dump($error);
			}
			break;
		case 'edit_product':
			$error = $product_id = update_node($id, $node_name, $node_status, $node_type, $node_content);	
			if(is_int($product_id)){
				if(isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0){
					$error = $thumb_id = save_node(get_home_url().'img/'.$product_id.'-'.$_FILES['thumbnail']['name'], 'publish', 'attachment');	
					if(is_int($thumb_id)){	
						move_uploaded_file($_FILES['thumbnail']['tmp_name'], ABSPATH.'img/'.$product_id.'-'.$_FILES['thumbnail']['name']);
						update_node_meta($product_id, 'product_thumb', $thumb_id);
					}
				}
				update_node_meta($product_id, 'category', serialize($category));
				update_node_meta($product_id, 'product_price', $product_price);
				update_node_meta($product_id, 'office', serialize($office));
				header('Location: '.get_admin_url('ecommerce.php?page=products'));
			}
			break;
		case 'add_office': 
			$error = $office_id = add_category($name, $description, $taxonomy);
			if(is_int($office_id)){
				header('Location: '.get_admin_url('ecommerce.php?page=offices'));
			}else{		
				admin_header();
				include 'ecommerce/categories.php';
				echo '	<script type="text/javascript">

							jQuery(document).ready(function(){
								jQuery(".nav-ecommerce").addClass("active");
								jQuery("#ecommerce-subitems").addClass("in");
								<?php if(isset($_GET["page"])): ?>
									jQuery(".sub-<?php echo $_GET["page"]?> a").addClass("active");
								<?php endif; ?>
							})

						</script>';
				admin_footer();
				die;
			}
			break;
		case 'edit_office':
			$error = $office_id = edit_category($id, $name, $description);
			if(is_int($office_id)){
				header('Location: '.get_admin_url('ecommerce.php?page=offices'));
			}else{		
				admin_header();				 
				include 'ecommerce/categories.php';
				echo '	<script type="text/javascript">

							jQuery(document).ready(function(){
								jQuery(".nav-ecommerce").addClass("active");
								jQuery("#ecommerce-subitems").addClass("in");
								<?php if(isset($_GET["page"])): ?>
									jQuery(".sub-<?php echo $_GET["page"]?> a").addClass("active");
								<?php endif; ?>
							})

						</script>';
				admin_footer();
				die;
			}
			break;
		default:
			# code...
			break;

	}
 
}

$action = (isset($_GET['action']))? $_GET['action'] : null;     
$page = (isset($_GET['page']))? $_GET['page'] : 'products'; 

switch ($page) { 	
 	case 'offices':

 		if(!$action){

	 		$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;	
			$taxonomy = 'office';	
	 		$offices = get_categories($offset, $limit, $taxonomy);
	 	}elseif($action == 'edit_office'){

	 		$id = isset($_GET['id'])? $_GET['id']: 0;
	 		$office = get_category($id);
	 		if(is_array($office))
	 			extract($office);

	 	}elseif($action == 'delete'){

	 		$id = isset($_GET['id'])? $_GET['id']: 0;
	 		if(!delete_category($id))
	 			$error['delete'] = 'Сталася невідома помилка';
	 		$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;		
	 		$taxonomy = 'office';	
	 		$offices = get_categories($offset, $limit, $taxonomy);


	 	}

 		admin_header();
 		include 'ecommerce/offices.php';
 		break;
 	case 'categories': 

 		if(!$action){

	 		$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;	
			$taxonomy = 'category';	
	 		$categories = get_categories($offset, $limit, $taxonomy);

	 	}elseif($action == 'edit_category'){

	 		$id = isset($_GET['id'])? $_GET['id']: 0;
	 		$category = get_category($id);
	 		if(is_array($category))
	 			extract($category);

	 	}elseif($action == 'delete'){

	 		$id = isset($_GET['id'])? $_GET['id']: 0;
	 		if(!delete_category($id))
	 			$error['delete'] = 'Сталася невідома помилка';
	 		$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;		
	 		$taxonomy = 'category';	
	 		$categories = get_categories($offset, $limit, $taxonomy);


	 	}

	 	admin_header();
 		include 'ecommerce/categories.php';
 		break;

 	case 'products':

 		if(!$action){

 			$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;		
	 		$products = get_products($offset, $limit);
	 		// var_dump($products); die;
 		}elseif($action == 'add_product'){
 			$categories = get_categories(-1, -1, 'category');
 			$offices = get_categories(-1, -1, 'office');
 		}elseif($action == 'edit_product'){
 			$categories = get_categories(-1, -1, 'category');
 			$offices = get_categories(-1, -1, 'office');
 			$id = isset($_GET['id'])? $_GET['id']: 0;
 			$product = get_node($id);
 			extract($product);
 		}elseif($action == 'delete'){
 			$id = isset($_GET['id'])? $_GET['id']: 0;
 			delete_node($id);
 			delete_node_meta($id);
 			$limit = 10;
			$paged = 1;
			if(isset($_GET['paged']))
				$paged = $_GET['paged'];		
			if(isset($paged))
				$offset = ($paged - 1) * $limit;		
	 		$products = get_products($offset, $limit);
 		}
 		admin_header(); 		
 		include 'ecommerce/products.php';
 		break;
 	default:
 		admin_header(); 		
 		include 'ecommerce/products.php';
 		break;
 } 
?>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery(".nav-ecommerce").addClass('active');
			jQuery("#ecommerce-subitems").addClass('in');
			<?php if(isset($_GET['page'])): ?>
				jQuery(".sub-<?php echo $_GET['page']?> a").addClass('active');
			<?php endif; ?>
		})
	</script>
<?php

admin_footer();

?>