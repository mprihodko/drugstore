<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Ліки 
        </h1>
        <ol class="breadcrumb">
        	<li >
                <a href="<?php admin_url()?>"><i class="fa fa-dashboard"></i> Керування </a>
            </li>
            <li >
            <?php if($action != null): ?>    
                <a href="<?php admin_url('ecommerce.php?page=products')?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Ліки </a>
            <?php elseif($action == null): ?>
                <i class="fa fa-shopping-cart" aria-hidden="true"></i> Ліки 
            <?php endif; ?> 
            </li>         
            <?php if($action == 'edit_product'): ?>
	            <li class="active">
	                <i class="fa fa-pencil"></i> Редагування
	            </li>
	        <?php elseif($action == 'add_product'): ?>
	        	<li class="active">
	                <i class="fa fa-pencil"></i> Нова Позиція
	            </li>
	        <?php endif; ?>
        </ol>
    </div>
</div>
<!-- /.row -->

<?php if(!$action || $action == 'delete'): ?>
    <!-- ADD PRODUCT BUTTON -->
    <div class="row clearfix text-right">
        <div class="col-lg-6">
            <p class="text-danger"><?php echo (isset($error['delete'])? $error['delete'] : ''); ?></p>
        </div>
        <div class="col-lg-6">
            <p><a class="btn btn-info btn" href="?page=products&action=add_product">Створити Нову Позицію</a></p>
        </div>
    </div>
    <div class="row clearfix ">

        <div class="col-lg-12">
            <table class="table table-hover">

                <thead>
                    
                    <th>Зображення</th>
                    <th>Назва</th>
                    <th>Ціна</th>
                    <th>Наявність</th>
                    <th>Дії</th>
                </thead>
                <tbody>
                <?php if(isset($products) && $products->num_rows>0): ?>
                        <?php foreach ($products->products as $product): extract($product); ?>
                        <?php $image_url = get_product_attachment($id); ?>
                        <tr>
                            
                            <td><?php echo ($image_url)? '<img height="100" src="'.$image_url.'">' : ''  ?></td>
                            <td><?php echo $node_name; ?></td>
                            <td><?php echo number_format(get_node_meta($id, 'product_price'), 2, ".", ' ');?></td>
                            <td></td>
                            <td>
                                <a href="?page=products&action=edit_product&id=<?php echo $id; ?>" class="btn btn-success fa fa-pencil"></a>
                                <a href="?page=products&action=delete&id=<?php echo $id; ?>" class="btn btn-danger fa fa-trash "></a>
                            </td>
                        </tr>
                    <?php endforeach;?>
                <?php endif; ?> 
                </tbody>

            </table>
        </div>
    </div>

    <?php if($products->num_rows>1): ?>

        <!-- pagination  -->
        <div class="row clearfix text-right">
            <div class="col-lg-12">
                <?php echo pagination($products->num_rows, '?page=products'); ?>
            </div>
        </div>

    <?php endif; ?>
<?php else: 

    if(!isset($id))
        $id = 0; ?>

    <form action="<?php admin_url('ecommerce.php?page=products'); ?>" method="POST" enctype="multipart/form-data">
  
        <input type="hidden" name="action" value="<?php echo $action; ?>">
        <input type="hidden" name="id" value="<?php echo  $id; ?>">
        <input type="hidden" name="node_type" value="product"> 

        <div class="form-group <?php echo (isset($error['name'])? 'has-error' : '') ?>" >
            <label for="product_name" >Назва Позиції</label>
            <input type="text" id="product_name" class="form-control" name="node_name" value="<?php echo (isset($node_name))? $node_name : '' ?>">
            <small class="text-danger" ><?php echo (isset($error['node_name'])? $error['node_name'] : '') ?></small>
        </div>
        <?php 
        $product_price = 0;
        if($id>0)
            $product_price = get_node_meta($id, 'product_price'); 

        ?>
        <div class="form-group <?php echo (isset($error['product_price'])? 'has-error' : '') ?>" >
            <label for="product_price" >Ціна Позиції</label>
            <input type="number"  min="0" step="0.01" id="product_price" class="form-control" name="product_price" value="<?php echo ($product_price)? number_format($product_price, 2, ".", '') : '0.00' ?>">
            <small class="text-danger" ><?php echo (isset($error['product_price'])? $error['product_price'] : '') ?></small>
        </div>
        <div class="form-group"> 
            <label>Категорії</label>
            <?php 
            $product_categories = array();
            if($id>0)
                $product_categories = unserialize(get_node_meta($id, 'category'));  ?>
             <?php if(isset($categories) && count($categories->num_rows)>0): ?>
                <div class="row">
                    <div class="checkbox col-sm-12">
                        <?php foreach ($categories->categories as $category):  ?>
                            <label for="category-<?php echo $category['id']?>" class="col-xs-2">
                                <input type="checkbox" id="category-<?php echo $category['id']?>" name="category[]" value="<?php echo $category['id']?>" <?php echo ($product_categories && in_array($category['id'], $product_categories))? "checked" : '' ?>> - <?php echo $category['name']?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
        <div class="form-group"> 
            <label>Відділення</label>
             <?php 
            $product_offices = array();
            if($id>0)
                $product_offices = unserialize(get_node_meta($id, 'office'));  ?> 
             <?php if(isset($offices) && count($offices)>0): ?>
                <div class="row">
                    <div class="checkbox col-sm-12">
                        <?php foreach ($offices->categories as $office): ?>
                            <label for="office-<?php echo $office['id']?>" class="col-xs-2">
                                <input type="checkbox" id="office-<?php echo $office['id']?>" name="office[]" value="<?php echo $office['id']?>" <?php echo ($product_offices && in_array($office['id'], $product_offices))? "checked" : '' ?>> - <?php echo $office['name']?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
        <div class="form-group">
            <label for="description" >Інформація про позицію</label>
            <textarea id="description" name="node_content" rows="10" class="form-control"><?php echo (isset($node_content))? $node_content : '' ?></textarea>
        </div>
       
        <div class="form-group"> 
            <label>Зображення товару</label>
            <?php if(isset($id) && $image_url = get_product_attachment($id)): ?>
                <p><img src="<?php echo $image_url ?>" width="200"></p>
            <?php endif; ?>
            <input type="file" name="thumbnail" class="form-control">
        </div>
        <div class="form-group text-right">
            <button class="btn btn-info" type="submit" name="node_status" value="publish">Зберегти</button>
        </div>
    </form>



<?php endif; ?>

