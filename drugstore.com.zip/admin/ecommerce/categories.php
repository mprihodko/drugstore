<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Категорії 
        </h1>
        <ol class="breadcrumb">
        	<li >
                <a href="<?php admin_url()?>"><i class="fa fa-dashboard"></i> Керування </a>
            </li>
            <li >
            <?php if($action != null): ?>    
                <a href="<?php admin_url('ecommerce.php?page=categories')?>"><i class="fa fa-database" aria-hidden="true"></i> Категорії </a>
            <?php elseif($action == null): ?>
                <i class="fa fa-database" aria-hidden="true"></i> Категорії 
            <?php endif; ?>
            </li>
            <?php if($action == 'edit_category'): ?>
	            <li class="active">
	                <i class="fa fa-pencil"></i> Редагування
	            </li>
	        <?php elseif($action == 'add_category'): ?>
	        	<li class="active">
	                <i class="fa fa-pencil"></i> Нова Категорія
	            </li>
	        <?php endif; ?>
        </ol>
    </div>
</div>
<!-- /.row -->

<?php if(!$action || $action=='delete'): ?>

    <!-- ADD Office BUTTON -->
    <div class="row clearfix text-right">
        <div class="col-lg-6">
            <p class="text-danger"><?php echo (isset($error['delete'])? $error['delete'] : ''); ?></p>
        </div>
        <div class="col-lg-6">
            <p><a class="btn btn-info btn" href="?page=categories&action=add_category">Додати Категорію</a></p>
        </div>
    </div>

    <div class="row clearfix ">

        <div class="col-lg-12">
        <!-- Render categories table -->
            <table class="table table-hover">

                <thead>
                    
                    <th>Назва</th>
                    <th>Коротка інформація</th>
                    <th>Дії</th>
                </thead>
                <tbody>

                    <?php if(isset($categories) && $categories->num_rows>0): ?>
                        <?php foreach ($categories->categories as $category): extract($category); ?>
                            <tr>
                                
                                <td width="20%"><?php echo $name ?></td>                
                                <td width="50%"><?php echo trim(mb_substr($description, 0, 200)) ?>...</td>
                                <td>
                                    <a href="?page=categories&action=edit_category&id=<?php echo $id; ?>" class="btn btn-success fa fa-pencil"></a>
                                    <a href="?page=categories&action=delete&id=<?php echo $id; ?>" class="btn btn-danger fa fa-trash "></a>
                                </td>
                            </tr>
                        <?php endforeach;?>
                    <?php endif; ?> 
                </tbody>

            </table>
        </div>
    </div>

    <?php if($categories->num_rows>1): ?>

        <!-- pagination  -->
        <div class="row clearfix text-right">
            <div class="col-lg-12">
                <?php echo pagination($categories->num_rows, '?page=categories'); ?>
            </div>
        </div>

    <?php endif; ?>
<?php else: ?>

    <form action="<?php admin_url('ecommerce.php?page=categories')?>" method="POST">
        <input type="hidden" name="action" value="<?php echo $action; ?>">
        <input type="hidden" name="id" value="<?php echo (isset($id))? $id : '0' ?>">
        <input type="hidden" name="taxonomy" value="category">
        <div class="form-group <?php echo (isset($error['name'])? 'has-error' : '') ?>" >
            <label for="category_name" >Назва Категорії</label>
            <input type="text" id="category_name" class="form-control" name="name" value="<?php echo (isset($name))? $name : '' ?>">
            <small class="text-danger" ><?php echo (isset($error['name'])? $error['name'] : '') ?></small>
        </div>
        <div class="form-group">
            <label for="description" >Коротке описання</label>
            <textarea id="description" name="description" rows="10" class="form-control"><?php echo (isset($description))? $description : '' ?></textarea>
        </div>
        <div class="form-group text-right">
            <button class="btn btn-info" type="submit" name="submit">Зберегти</button>
        </div>
    </form>

<?php endif; ?>