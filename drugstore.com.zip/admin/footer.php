		    	</div>
    		<!-- /.container-fluid -->

			</div>	
	
		</div>
	    <!-- /#wrapper -->

	   

	    <!-- Bootstrap Core JavaScript -->
	    <script src="assets/js/bootstrap.min.js"></script>


	</body>

</html>