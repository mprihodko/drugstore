<?php 

require_once('../config.php' );

if(defined("DEBUG") && DEBUG){
	ini_set('error_reporting', E_ALL);
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
}

if(isset($_GET['logout'])){
	unset($_SESSION);
	session_unset();
}

if(admin_init()){

	if(file_exists(ABSPATH . 'admin/admin.php')){
		require( ABSPATH . 'admin/admin.php' );
	}else{
		exit('Не удается найти файл ' . ABSPATH .'admin/admin.php');
	}
}