<?php
require_once('../config.php' );
admin_init();

admin_header();


if($_GET['page'] == 'new'):

$order_list = get_orders();
?>
<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Замовлення 
        </h1>
        <ol class="breadcrumb">
        	<li >
                <a href="<?php admin_url()?>"><i class="fa fa-dashboard"></i> Керування </a>
            </li>           
        	<li class="active">
                <i class="fa fa-pencil"></i> Новi Замовлення
            </li>	       
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row clearfix ">

	<div class="col-lg-12">
		<!-- Render user table -->
		<table class="table table-hover">

			<!-- table header -->
			<thead>
				<th width="15%">ID</th>
				<th width="30%">Замовлені Ліки</th>
				<th width="15%">Загальна сума</th>
				<th width="20%">Покупець</th>			 
				<th width="20%">Дії</th>       			      			
			</thead>

			<!-- table body -->
			<tbody>

				<?php	
				if(is_object($order_list)):
					foreach ($order_list->orders as $order) : extract($order); 

				?>

	    			<tr class="order-<?php echo $username; ?> " id="order-<?php echo $id; ?>">
	        			<td width="15%"><h4><?php echo $node_name; ?></h4></td>
	        			<td>
	        				<ul class="orders-list">
	        					
	        				<?php 
	        					$items = get_node_meta($id, 'order_items');
	        					if($items){
	        						$items = json_decode($items);
	        					}
	        					$order_total = 0;
	        					if(count($items)){
	        						foreach ($items as $key => $item) {
	        							$product = get_product($item->product);
	        							$office = get_category($item->office);
	        							echo "<li><a href='".get_admin_url('ecommerce.php?page=products&action=edit_product&id='.$product['id'])."''>".$product['node_name']."</a> - ".$item->qty."шт. <br> ".$office['name']."</li>";
	        							$order_total += (float)$product['price']*$item->qty;
	        						}
	        					}

	        				?>
	        				</ul>
	        			</td>
	        			<td>
	        				<?php echo number_format($order_total, 2, ".", " "); ?> грн.
	        			</td>
	        			<td>
	        				<?php 
	        				$user_id= get_node_meta($id, 'order_user'); 
	        				$user = get_user($user_id);
	        				echo "<span class='user_name'>".$user['username']."</span><br><span class='user_email'>".$user['user_email']."</span>";
	        				?>
	        			</td>
	        			<td>
	        				<a href="?page=complete&action=complete_order&id=<?php echo $id; ?>" class="btn btn-info btn-lg fa fa-eye "></a>	        				
	        			</td>
	    			</tr>

				<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	<!-- Render user table -->


	</div>
</div>

<?php elseif($_GET['page'] == 'complete' ): 


if(isset($_GET['action']) && $_GET['action'] =='complete_order' && isset($_GET['id']))
	complete_order($_GET['id']);

$order_list = get_orders('complete');
?> 

	<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Замовлення 
        </h1>
        <ol class="breadcrumb">
        	<li >
                <a href="<?php admin_url()?>"><i class="fa fa-dashboard"></i> Керування </a>
            </li>           
        	<li class="active">
                <i class="fa fa-pencil"></i> Виконанi Замовлення
            </li>	       
        </ol>
    </div>
</div>
<!-- /.row -->

<div class="row clearfix ">

	<div class="col-lg-12">
		<!-- Render user table -->
		<table class="table table-hover">

			<!-- table header -->
			<thead>
				<th width="15%">ID</th>
				<th width="40%">Замовлені Ліки</th>
				<th width="20%">Загальна сума</th>
				<th width="25%">Покупець</th>			 
				      			      			
			</thead>

			<!-- table body -->
			<tbody>

				<?php	
				if(is_object($order_list)):
					foreach ($order_list->orders as $order) : extract($order); 

				?>

	    			<tr class="order-<?php echo $username; ?> " id="order-<?php echo $id; ?>">
	        			<td width="15%"><h4><?php echo $node_name; ?></h4></td>
	        			<td>
	        				<ul class="orders-list">
	        					
	        				<?php 
	        					$items = get_node_meta($id, 'order_items');
	        					if($items){
	        						$items = json_decode($items);
	        					}
	        					$order_total = 0;
	        					if(count($items)){
	        						foreach ($items as $key => $item) {
	        							$product = get_product($item->product);
	        							$office = get_category($item->office);
	        							echo "<li><a href='".get_admin_url('ecommerce.php?page=products&action=edit_product&id='.$product['id'])."''>".$product['node_name']."</a> - ".$item->qty."шт. <br> ".$office['name']."</li>";
	        							$order_total += (float)$product['price']*$item->qty;
	        						}
	        					}

	        				?>
	        				</ul>
	        			</td>
	        			<td>
	        				<?php echo number_format($order_total, 2, ".", " "); ?> грн.
	        			</td>
	        			<td>
	        				<?php 
	        				$user_id= get_node_meta($id, 'order_user'); 
	        				$user = get_user($user_id);
	        				echo "<span class='user_name'>".$user['username']."</span><br><span class='user_email'>".$user['user_email']."</span>";
	        				?>
	        			</td>
	        			 
	    			</tr>

				<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	<!-- Render user table -->


	</div>
</div>

<?php endif; ?>

<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery(".nav-orders").addClass('active');
			jQuery("#orders-subitems").addClass('in');
			<?php if(isset($_GET['page'])): ?>
				jQuery(".sub-<?php echo $_GET['page']?> a").addClass('active');
			<?php endif; ?>
		})
	</script>
<?php

admin_footer();

?>